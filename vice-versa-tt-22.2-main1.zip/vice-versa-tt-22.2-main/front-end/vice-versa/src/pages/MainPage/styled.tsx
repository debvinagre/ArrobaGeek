import styled from "styled-components/native";
//@ts-ignore
import background from "../../../assets/ImgHomePage/Rectangle100.png";
export const Container = styled.View`
flex: 1;
background-image: url(${background})`;

export const FraseBoi = styled.Image`
width:269;
height:121;
margin-left:15px
`;
