import styled from "styled-components/native";
//@ts-ignore

import background from "../../../assets/ImgMyProducts/Rectangle100.png";


export const Container = styled.View`
  flex: 1;
  background-image: url(${background});
`;
