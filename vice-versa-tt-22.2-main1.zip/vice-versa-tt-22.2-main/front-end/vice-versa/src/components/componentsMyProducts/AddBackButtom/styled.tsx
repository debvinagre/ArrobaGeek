import styled from "styled-components/native";

export const ButtomContainer = styled.View`
  justify-content: space-between;
  align-items: center;
  display: flex;
  flex-direction: row;
  margin-left: 20;
  margin-right: 20;
`;
