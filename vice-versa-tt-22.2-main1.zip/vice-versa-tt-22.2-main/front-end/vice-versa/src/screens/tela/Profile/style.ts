
import styled from "styled-components/native";

export const Container = styled.View`
    margin: auto ;
    background-color: #D9CEF2;
    width: 414px;
    height: 896px;
    
`;

export const ImageVoltar = styled.Image`
    width: 30px;
    height: 30px;
    margin-top: 12px;
    margin-left: 15px;
`;








